function showImage(imageSrc) {
    const zoomedImage = document.getElementById('zoomedImage');
    zoomedImage.src = imageSrc;
}
