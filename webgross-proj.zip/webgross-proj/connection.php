<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "infinity";

    $con = mysqli_connect($host, $user, $pass, $db);

    if ($con){
        echo "";
    }
    else {
        echo "";
    }
?>