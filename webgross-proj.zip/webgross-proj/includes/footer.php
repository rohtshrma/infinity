<!-- footer.php -->
<footer>
    <p>&copy; 2024 My PHP Project. All rights reserved.</p>
</footer>
